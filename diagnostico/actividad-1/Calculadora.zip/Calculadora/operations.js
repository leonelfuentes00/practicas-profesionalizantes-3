document.addEventListener("DOMContentLoaded", function () {
    const pantalla = document.getElementById("view");
    const botones = document.querySelectorAll(".num, .op, .igual, .borrar");

    let expresion = "";

    function updateScreen() {
        pantalla.value = expresion || "0";
    }

    botones.forEach(boton => {
        boton.addEventListener("click", () => {
            const valor = boton.textContent;

            if (valor === "Borrar") {
                expresion = "";
            } else if (valor === "=") {
                try {
                    expresion = eval(expresion);
                } catch {
                    expresion = "Error";
                }
            } else {
                expresion += valor;
            }
            updateScreen();
        });
    });

    updateScreen();
});
